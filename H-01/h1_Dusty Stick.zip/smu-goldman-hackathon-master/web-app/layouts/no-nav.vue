<template>
  <div class="h-screen bg-goldman-grey">
    <div>
      <Nuxt/>
    </div>
  </div>
</template>

<style>

</style>
<script>
export default {
  components: {}
}
</script>
